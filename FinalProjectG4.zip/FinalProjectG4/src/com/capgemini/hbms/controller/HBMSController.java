package com.capgemini.hbms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.hbms.service.IUserService;

@Controller
public class HBMSController {
	
	@Autowired
	private IUserService userService;
	
	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}
	
	@RequestMapping("/")
	public String showHomePage()
	{
		return "home";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginPage()
	{
		return "loginPage";
		
	}
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String RegisterPage()
	{
		return "registerPage";
		
	}

}
