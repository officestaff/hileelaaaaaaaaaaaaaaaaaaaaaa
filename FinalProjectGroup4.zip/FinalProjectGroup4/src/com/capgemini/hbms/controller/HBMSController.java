package com.capgemini.hbms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.hbms.service.IUserService;

@Controller
public class HBMSController {
	
	@Autowired
	private IUserService userService;
	
	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}
	
	@RequestMapping("/")
	public String showHomePage()
	{
		return "myHomepage";
	}
	
	 @RequestMapping(value="/hiHome",params="login",method=RequestMethod.POST)
	    public String showLoginPage()
	    {
	        
			return "hi";
	    }
	    @RequestMapping(value="/hiHome",params="register",method=RequestMethod.POST)
	    public String showRegisterPage()
	    {
	       
			return "hi2";
	    } 
	

}
