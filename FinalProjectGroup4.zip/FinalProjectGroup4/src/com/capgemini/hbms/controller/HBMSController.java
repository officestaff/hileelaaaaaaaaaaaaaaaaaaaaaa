package com.capgemini.hbms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import java.util.List;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.IUserService;



@Controller
public class HBMSController {
	
	@Autowired
	private IUserService userService;
	
	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}
	
	@RequestMapping("/")
	public String showHomePage()
	{
		return "myHomepage";
	}
	
	 @RequestMapping(value="/hiHome",params="login",method=RequestMethod.POST)
	    public String showLoginPage()
	    {
	        
			return "myLogin";
	    }
	    @RequestMapping(value="/hiHome",params="register",method=RequestMethod.POST)
	    public String showRegisterPage()
	    {
	       
			return null;
	    }
	    
	    @RequestMapping(value="/hiLogin",params="admin",method=RequestMethod.POST)
	    public String showAdminPage()
	    {
	        
			return "myAdmin";
	    }
	
	    @RequestMapping(value="/hiLogin",params="customer",method=RequestMethod.POST)
	    public String showCustomerPage()
	    {
	        
			return "hi";
	    }
	    
	    @RequestMapping(value="/hiLogin",params="employee",method=RequestMethod.POST)
	    public String showEmployeePage()
	    {
	        
			return "hi2";
	    }
	   
	    @RequestMapping("/viewHotels")
	    public ModelAndView showHotels()
	    {
	    	ModelAndView mv = null;
			try 
			{
				List<HotelDetailsBean> hotelsList = userService.viewHotels();
				mv = new ModelAndView("viewHotels","hotelsList",hotelsList);
	    	
	    }
			catch (HBMSException e)
			{
				mv = new ModelAndView("error");
				mv.addObject("exception", "An Error Occured "+e.getMessage());
			}
			return mv;
	    

}
	    @RequestMapping("/updateHotels")
	    public String updateHotels()
	    {
			return "updateHotel";
	    	
	    }
	    
	    @RequestMapping(value="/reteriveHotelByCity",method=RequestMethod.POST)
		public ModelAndView showTraineeById(@RequestParam("city") String city)
		{
			ModelAndView mv = null;
			
			try {
				List<HotelDetailsBean> hotelbean = userService.getHotelByCity(city);
				
				mv = new ModelAndView("updateHotel","hotelbean",hotelbean);
			}
			catch (HBMSException e)
			{
				mv = new ModelAndView("error");
				mv.addObject("exception", "An Error Occured "+e.getMessage());
			}
			return mv;
			
		}
	    
	    @RequestMapping("/showHotelById")
	    public String showHotelById()
	    {
	    	return "showHotelbyId";
	    }
	    
	    @RequestMapping(value="/retrieveById",method=RequestMethod.POST)
		public ModelAndView showTraineeById(@ModelAttribute("hotelbean") HotelDetailsBean bean)
		{
			ModelAndView mv = null;
			
			try 
			{
				HotelDetailsBean hotelbean = userService.getHotelById(bean.getHotelId());
				mv = new ModelAndView("showHotelbyId","hotelbean",hotelbean);
			}
			catch (HBMSException e)
			{
				mv = new ModelAndView("error");
				mv.addObject("exception", "An Error Occured "+e.getMessage());
			}
			return mv;
			
		}
	    @RequestMapping(value="/updateHotel",method=RequestMethod.POST)
		public ModelAndView updateTrainee(@ModelAttribute("hotelbean") HotelDetailsBean bean) {
			
			ModelAndView mv = null;
			
			try {
			
				HotelDetailsBean hotelbean = 
						userService.modifyHotel(bean.getHotelId(),bean.getCity(), bean.getHotelName(), bean.getAddress(), bean.getDescription()
								, bean.getAvgRatePerNight(),bean.getPhoneNo1(), bean.getPhoneNo2(), bean.getRating(), bean.getEmail(), bean.getFax());
				mv = new ModelAndView("modifysuccess","hotelbean",hotelbean);
			} 
			
			catch (HBMSException e)
			{
				mv = new ModelAndView("error");
				mv.addObject("exception", "An Error Occured "+e.getMessage());
			}
			return mv;
			
		}
	    }
