package com.capgemini.hbms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

@Repository
@Transactional
public class HBMSDaoImpl implements IHBMSDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int RegisterUser(UserDetailsBean userDetails) throws HBMSException {
		int userId = 0;

		/*Logger logger = Logger.getRootLogger();*/
		
		try{
			entityManager.persist(userDetails);
			entityManager.flush();

			userId = userDetails.getUserId();

			/*logger.info("UserDetailsDAO : User registered !!");*/
			
		} catch(Exception e){
			/*logger.info("UserDetailsDAO : User cannot be registered\n" + e.getMessage());*/
			throw new HBMSException("Error in DAO Register User" +e.getMessage()); //Throws error	
		}
		
		
	return userId;
	}

	@Override
	public List<UserDetailsBean> usersDetail() throws HBMSException {
		
			List<UserDetailsBean> usersList = new ArrayList<UserDetailsBean>();
		
		try{
			TypedQuery<UserDetailsBean> qry = entityManager.createQuery("from UserDetailsBean",UserDetailsBean.class);
			
			usersList = qry.getResultList();
			
		} catch(Exception e){

			throw new HBMSException("Error in DAO GetAllUser Details" +e.getMessage()); //Throws error	
		}
		
		return usersList;
	}

	@Override
	public UserDetailsBean getUserDetail(int userId) throws HBMSException {
		UserDetailsBean userDetailsBean = new UserDetailsBean();
		
		try
		{
		
		userDetailsBean = entityManager.find(UserDetailsBean.class,userId);
		} catch(Exception e){

		throw new HBMSException("Error in GetSingle User Detail "+e.getMessage()); //Throws error	
		}
	
		return userDetailsBean;
		}

	@Override
	public List<HotelDetailsBean> viewHotels() throws HBMSException {
		
	List<HotelDetailsBean> hotelsList = null;
		
		try{
			String jpql = "SELECT hotelbean FROM HotelDetailsBean hotelbean";
			
			
			
			TypedQuery<HotelDetailsBean> qry = entityManager.createQuery(jpql,HotelDetailsBean.class);
			
			hotelsList = qry.getResultList();
			
		} catch(Exception e){

			throw new HBMSException("Unable to get all Hotels in dao Layer" +e.getMessage()); //Throws error	
		}
		
		return hotelsList;
	}
	
	

}
