package com.capgemini.hbms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

@Repository
@Transactional
public class HBMSDaoImpl implements IHBMSDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int RegisterUser(UserDetailsBean userDetails) throws HBMSException {
		int userId = 0;

		/*Logger logger = Logger.getRootLogger();*/
		
		try{
			entityManager.persist(userDetails);
			entityManager.flush();

			userId = userDetails.getUserId();

			/*logger.info("UserDetailsDAO : User registered !!");*/
			
		} catch(Exception e){
			/*logger.info("UserDetailsDAO : User cannot be registered\n" + e.getMessage());*/
			throw new HBMSException("Error in DAO Register User" +e.getMessage()); //Throws error	
		}
		
		
	return userId;
	}

	@Override
	public List<UserDetailsBean> usersDetail() throws HBMSException {
		
			List<UserDetailsBean> usersList = new ArrayList<UserDetailsBean>();
		
		try{
			TypedQuery<UserDetailsBean> qry = entityManager.createQuery("from UserDetailsBean",UserDetailsBean.class);
			
			usersList = qry.getResultList();
			
		} catch(Exception e){

			throw new HBMSException("Error in DAO GetAllUser Details" +e.getMessage()); //Throws error	
		}
		
		return usersList;
	}

	@Override
	public UserDetailsBean getUserDetail(int userId) throws HBMSException {
		UserDetailsBean userDetailsBean = new UserDetailsBean();
		
		try
		{
		
		userDetailsBean = entityManager.find(UserDetailsBean.class,userId);
		} catch(Exception e){

		throw new HBMSException("Error in GetSingle User Detail "+e.getMessage()); //Throws error	
		}
	
		return userDetailsBean;
		}

	@Override
	public List<HotelDetailsBean> viewHotels() throws HBMSException {
		
	List<HotelDetailsBean> hotelsList = null;
		
		try{
			String jpql = "SELECT hotelbean FROM HotelDetailsBean hotelbean";
			
			
			
			TypedQuery<HotelDetailsBean> qry = entityManager.createQuery(jpql,HotelDetailsBean.class);
			
			hotelsList = qry.getResultList();
			
		} catch(Exception e){

			throw new HBMSException("Unable to get all Hotels in dao Layer" +e.getMessage()); //Throws error	
		}
		
		return hotelsList;
	}

	@Override
	public List<HotelDetailsBean> getHotelByCity(String city) throws HBMSException {
		
		List<HotelDetailsBean> bean = null;
		try{
	
		String jpql = "SELECT hotelbean FROM HotelDetailsBean hotelbean WHERE hotelbean.city=:city";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("city", city);
		int ret= query.executeUpdate();
		
		if(ret == 0)
		{
			throw new HBMSException("Unable to Reterive the Hotels with the City "+city);
		}
		}
		
		catch(Exception ex)
		{
		throw new HBMSException(ex.getMessage());
		}
		return bean;
	
	}

	@Override
	public HotelDetailsBean getHotelById(String hotelId) throws HBMSException {
		
		HotelDetailsBean hotelbean = null;
		try{
			hotelbean = entityManager.find(HotelDetailsBean.class, hotelId);		
		}
		catch(Exception ex)
		{
		throw new HBMSException(ex.getMessage());
		}
		return hotelbean;
	}

	@Override
	public HotelDetailsBean modifyHotel(String hotelId, String city,
			String hotelName, String address, String description,
			double avgRatePerNight, String phoneNo1, String phoneNo2,
			String rating, String email, String fax) throws HBMSException {
		HotelDetailsBean hotelbean;
		try {
			hotelbean = entityManager.find(HotelDetailsBean.class, hotelId);
			hotelbean.setCity(city);
			hotelbean.setHotelName(hotelName);
			hotelbean.setAddress(address);
			hotelbean.setDescription(description);
			hotelbean.setAvgRatePerNight(avgRatePerNight);
			hotelbean.setPhoneNo1(phoneNo1);
			hotelbean.setPhoneNo2(phoneNo2);
			hotelbean.setRating(rating);
			hotelbean.setEmail(email);
			hotelbean.setFax(fax);
			
			entityManager.merge(hotelbean);
			
		}
		catch(Exception e){

			throw new HBMSException("Unable to Modify all Hotels in dao Layer" +e.getMessage()); //Throws error	
		}
		
		return hotelbean;
		
	}
	
	

}
