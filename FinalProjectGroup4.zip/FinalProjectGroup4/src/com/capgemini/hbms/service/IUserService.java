package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IUserService {
	
	int RegisterUser(UserDetailsBean userDetails) throws HBMSException;
	
	UserDetailsBean isValidUser(UserDetailsBean userDetails) throws HBMSException;

	UserDetailsBean getUserDetail(int userId) throws HBMSException;
	
	boolean isValidUserName(UserDetailsBean userDetails) throws HBMSException;
	
	boolean isValidCredentials(UserDetailsBean userDetails) throws HBMSException;
	
	List<HotelDetailsBean> viewHotels() throws HBMSException;
	
	List<HotelDetailsBean> getHotelByCity(String city) throws HBMSException;
	
	HotelDetailsBean getHotelById(String hotelId) throws HBMSException;
	
	public HotelDetailsBean modifyHotel(String hotelId, String city, String hotelName,
			String address, String description, double avgRatePerNight,
			String phoneNo1, String phoneNo2, String rating, String email,
			String fax) throws HBMSException;
}
