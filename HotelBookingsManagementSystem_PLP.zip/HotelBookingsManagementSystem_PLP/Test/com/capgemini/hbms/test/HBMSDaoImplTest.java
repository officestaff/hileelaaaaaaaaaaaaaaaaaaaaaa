package com.capgemini.hbms.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.dao.HBMSDaoImpl;
import com.capgemini.hbms.dao.IHBMSDao;
import com.capgemini.hbms.exception.HBMSException;

public class HBMSDaoImplTest {

	IHBMSDao hbmsDao;
	
	@Before
	public void setUp() throws Exception {
		hbmsDao = new HBMSDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		hbmsDao = null;
	}

	@Test
	public void testRegisterUser() {
		UserDetailsBean bean = new UserDetailsBean("Sagar","123","Customer","9974910166","9974910166","Vadodara","saga@gmail.com");
		int id = 0;
		try {
			id = hbmsDao.RegisterUser(bean);
			
			assertTrue(id!=0);
		} catch (HBMSException e) {
			assertEquals("DAO register Error",e.getMessage());
		}
	}
	
	@Test
	public void testViewHotels() {
		List<HotelDetailsBean> hotelList = new ArrayList<HotelDetailsBean>();
		try {
			hotelList = hbmsDao.viewHotels();
			
			assertTrue(hotelList!=null);
		} catch (HBMSException e) {
			assertEquals("Dao Hotel view error",e.getMessage());
		}
	}

	/*@Test
	public void testViewRooms() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetBookingDetail() {
		fail("Not yet implemented");
	}*/

}
