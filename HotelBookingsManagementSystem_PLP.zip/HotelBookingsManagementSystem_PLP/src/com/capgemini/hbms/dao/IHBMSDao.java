package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IHBMSDao {

	/* ===================USERS========================================== */
	int RegisterUser(UserDetailsBean userDetails) throws HBMSException;

	List<UserDetailsBean> usersDetail() throws HBMSException;

	UserDetailsBean getUserDetail(int userId) throws HBMSException;

	/* ==========================HOTEL======================================== */
	List<HotelDetailsBean> viewHotels() throws HBMSException;

	HotelDetailsBean viewHotel(String hotelId) throws HBMSException;

	/*
	 * ==========================ROOM
	 * DETAILS======================================
	 */

	List<String> getAllRoomIds() throws HBMSException;

	double getRoomRate(String roomId) throws HBMSException;

	List<RoomDetailsBean> getRoomHotelID() throws HBMSException;

	RoomDetailsBean getRoomDetail(String roomId) throws HBMSException;

	List<RoomDetailsBean> viewRooms(String hotelId) throws HBMSException;

	/*
	 * ==========================BOOKING DETAILS======================================
	 */

	int bookHotelRoom(BookingDetailsBean bookingDetailsBean)
			throws HBMSException;

	List<BookingDetailsBean> getBookingDetail(int bookingId)
			throws HBMSException;

	List<BookingDetailsBean> getBookingDetails(String userId)
			throws HBMSException;
}
