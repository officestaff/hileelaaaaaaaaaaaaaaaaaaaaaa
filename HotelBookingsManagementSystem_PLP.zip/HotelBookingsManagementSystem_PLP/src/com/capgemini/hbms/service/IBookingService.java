package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IBookingService {

	List<BookingDetailsBean> getBookingDetail(int bookingId) throws HBMSException;
	
	int bookHotelRoom(BookingDetailsBean bookingDetailsBean) throws HBMSException;

	List<BookingDetailsBean> getBookingDetails(String userId) throws HBMSException;
	
}
