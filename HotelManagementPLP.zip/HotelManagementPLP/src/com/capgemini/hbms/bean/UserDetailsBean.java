package com.capgemini.hbms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="users")
public class UserDetailsBean {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="userSeq")
	@SequenceGenerator(name="userSeq",sequenceName="user_id_sequence",allocationSize=1)
	@Column(name = "user_id")
	private int userId;
	
	@NotEmpty(message = "Please enter your password.")
	@Size(max=20,message="Password length should be of max 20 characters")
	@Column(name="password",length=20)
	private String password;
	
	@Column(name = "role",length=10)
	private String role;
	
	@NotEmpty(message = "Please enter the Username")
	@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Username must contain only alphabets")
	@Column(name = "user_name",unique=true,length=30)
	private String userName;
	
	@Size(min=7,max=10,message="Mobile Number Should Accept Only 10 digits")
	@Pattern(regexp = "^[7-9][0-9]+$", message = "Mobile Number should start with a digit 7, 8 or 9")
	@Column(name = "mobile_no",length=10)
	private String mobileNo;
	
	@Size(min=7,max=10,message="Phone Number Should Accept Only 10 digits")
	@Pattern(regexp = "^[0-9]+$", message = "Phone Number should contain only 10 digits")
	@Column(name = "phone",length=10)
	private String phone;
	
	@NotEmpty(message="Please enter Address")
	@Column(name = "address",length=70)
	private String address;

	@Email(message="Please enter a valid email")
	@NotEmpty(message="Please enter email")
	@Column(name = "email",length=40)
	private String email;
	
	public UserDetailsBean() {
		super();
	}
	

	public UserDetailsBean(String userName,String password, String role,
			String mobile_no, String phone, String address,
			String email) {
		super();
		this.password = password;
		this.role = role;
		this.userName = userName;
		this.mobileNo = mobile_no;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}


	
	
	public UserDetailsBean(int userId, String password, String role, String userName, String mobileNo, String phone,
			String address, String email) {
		super();
		this.userId = userId;
		this.password = password;
		this.role = role;
		this.userName = userName;
		this.mobileNo = mobileNo;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}


	public int getUserId() {
		return userId;
	}

	

	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public UserDetailsBean(String userName, String password, String role) {
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getMobile_no() {
		return mobileNo;
	}


	public void setMobile_no(String mobile_no) {
		this.mobileNo = mobile_no;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	@Override
	public String toString() {
		return "UserDetails [userId=" + userId + ", password=" + password
				+ ", role=" + role + ", userName=" + userName + ", mobile_no="
				+ mobileNo + ", phone=" + phone + ", address=" + address
				+ ", email=" + email + "]";
	}
	
	
	
	
	
}
