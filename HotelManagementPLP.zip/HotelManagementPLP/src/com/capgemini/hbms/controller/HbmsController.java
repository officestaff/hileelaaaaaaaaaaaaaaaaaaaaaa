package com.capgemini.hbms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.IUserService;



@Controller
public class HbmsController {

	
	List<UserDetailsBean> logged;
	@Autowired
	private IUserService userService;
	
	@RequestMapping("/showHomePage")
	public ModelAndView showHomePage() {
		return new ModelAndView("home");
	}

	@RequestMapping("/showLoginPage")
	public String showLoginPage() {
		System.out.println("coming in");
		//UserDetailsBean user = new UserDetailsBean();
		//return new ModelAndView("login", "user", user);
		return "login";
	}

	
//	@RequestMapping(value = "check", method = RequestMethod.POST)
//	public ModelAndView check(@RequestParam("submit") String action,
//			@ModelAttribute("userBean") UserDetailsBean userDetailsBean,
//			BindingResult result) {
//
//		ModelAndView mv = new ModelAndView();
//
//		if (action.equals("Register")) {
//			mv.setViewName("register");
//		} else if (action.equals("Login")) {
//			if (result.hasErrors()) {
//				mv.setViewName("error");
//				mv.addObject("errMsg", result);
//			} else {
//				try {
//
//					System.out.println(userDetailsBean);
//					boolean isValidUser = userService
//							.isValidCredentials(userDetailsBean);
//					System.out.println(isValidUser);
//					if (isValidUser
//							&& (userDetailsBean.getRole().equals("Customer") || userDetailsBean
//									.getRole().equals("Employee"))) {
//
//						UserDetailsBean userDetail = userService
//								.isValidUser(userDetailsBean);
//						mv.setViewName("userfunctions");
//						mv.addObject("userId", userDetail.getUserId());
//
//					} else if (isValidUser
//							&& userDetailsBean.getRole().equals("Admin")) {
//						mv.setViewName("loginsuccess");
//					} else {
//						mv.setViewName("login");
//						mv.addObject("loginCheck",
//								"Username or Password does not exist !!");
//						mv.addObject("");
//						
//					}
//
//				} catch (HBMSException e) {
//					mv.setViewName("error");
//					mv.addObject("errMsg", e.getMessage());
//				}
//			}
//		}
//
//		return mv;
//	}
	
	@RequestMapping("/checkLogin")
	public ModelAndView login(
			@ModelAttribute(value = "login") @Valid UserDetailsBean login,
			BindingResult result, Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		if (result.hasErrors()) {
			return new ModelAndView("login");
		} else {
			try {
				if (login.getPassword() != "" && login.getUserName() != "") {
					logged = userService.getAllUser(login.getUserName());
					if (!logged.isEmpty()) {
						if (login.getPassword().equals(
								logged.get(0).getPassword())) {
							if (logged.get(0).getRole().equals("admin")) {
								mv = new ModelAndView("Admin");
							} else if (logged.get(0).getRole()
									.equals("Employee")) {
								mv = new ModelAndView("Employee");
							}
						} else {
							mv.setViewName("login");
							model.addAttribute("msg", "Password Mismatch");
						}
					} else {
						mv.setViewName("login");
						model.addAttribute("msg", "No user found");
					}
				} else {
					mv = new ModelAndView("login");
					model.addAttribute("msg", "Enter all required fields");
				}
			} catch (HBMSException exception) {
				exception.printStackTrace();
			}
		}
		return mv;
	}
	
}
