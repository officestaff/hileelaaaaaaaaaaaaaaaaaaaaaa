package com.capgemini.hbms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;




@Repository
@Transactional
public class HBMSDaoImpl implements IHBMSDao {

	@PersistenceContext
	private EntityManager entityManager;
//	
//	@Override
//	public List<UserDetailsBean> usersDetail() throws HBMSException {
//	List<UserDetailsBean> usersList = new ArrayList<UserDetailsBean>();
//		
//		try{
//			System.out.println("entering usersDetail()");
//			
//			//TypedQuery<UserDetailsBean> qry = entityManager.createQuery("from UserDetailsBean",UserDetailsBean.class);
//			
//			//usersList = qry.getResultList();
//			String qstr = "SELECT m FROM UserDetailsBean m WHERE m.userName LIKE :pnumber";
//			TypedQuery<UserDetailsBean> query = entityManager.createQuery(qstr, UserDetailsBean.class);
//			query.setParameter("pnumber", "%" + userName + "%");
//			List<UserDetailsBean> loginList = query.getResultList();
//			return loginList;
//			System.out.println(usersList);
//			
//			
//		} catch(Exception e){
//
//			throw new HBMSException(e.getMessage()); //Throws error	
//		}
//		
//		return usersList;
//	}
//
//	@Override
//	public UserDetailsBean getUserDetail(int userId) throws HBMSException {
//		System.out.println(userId);
//		UserDetailsBean userDetailsBean = new UserDetailsBean();
//		
//		try{
//			/*TypedQuery<UserDetailsBean> qry = entityManager.createQuery("select * from UserDetailsBean where userName = :name",UserDetailsBean.class);
//			qry.setParameter("name", userName);
//			
//			userDetailsBean = qry.getSingleResult();*/
//			
//			userDetailsBean = entityManager.find(UserDetailsBean.class,userId);
//			
//			
//		} catch(Exception e){
//
//			throw new HBMSException(e.getMessage()); //Throws error	
//		}
//		
//		return userDetailsBean;
//	}

	@Override
	public List<UserDetailsBean> getAllUser(String userName)
			throws HBMSException {
		String qstr = "SELECT m FROM UserDetailsBean m WHERE m.userName LIKE :pnumber";
		TypedQuery<UserDetailsBean> query = entityManager.createQuery(qstr, UserDetailsBean.class);
		query.setParameter("pnumber", "%" + userName + "%");
		List<UserDetailsBean> loginList = query.getResultList();
		return loginList;
	}

	
}
