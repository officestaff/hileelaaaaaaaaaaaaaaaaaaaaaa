package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IHBMSDao {

	//List<UserDetailsBean> usersDetail() throws HBMSException;

	//UserDetailsBean getUserDetail(int userId) throws HBMSException;

	List<UserDetailsBean> getAllUser(String userName) throws HBMSException;

}
