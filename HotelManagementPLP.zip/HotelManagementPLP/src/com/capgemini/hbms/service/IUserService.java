package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IUserService {

	//boolean isValidCredentials(UserDetailsBean userDetailsBean)throws HBMSException;

	//UserDetailsBean isValidUser(UserDetailsBean userDetailsBean)throws HBMSException;

	//UserDetailsBean getUserDetail(int userId) throws HBMSException;

	List<UserDetailsBean> getAllUser(String userName)throws HBMSException;
}
