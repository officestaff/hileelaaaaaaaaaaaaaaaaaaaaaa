package com.capgemini.hbms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.dao.IHBMSDao;
import com.capgemini.hbms.exception.HBMSException;

@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	private IHBMSDao userDetailsDao;

	@Override
	public List<UserDetailsBean> getAllUser(String userName)
			throws HBMSException {
		return userDetailsDao.getAllUser(userName);
	}
	
	
//
//	@Override
//	public UserDetailsBean isValidUser(UserDetailsBean userDetails)
//			throws HBMSException {
//		boolean isValid = false;
//		List<UserDetailsBean> usersList = userDetailsDao.usersDetail();
//		UserDetailsBean userDetailsBean = new UserDetailsBean();
//		
//		
//		for(UserDetailsBean user : usersList){
//			if(user.getUserName().equals(userDetails.getUserName()) && user.getPassword().
//					equals(userDetails.getPassword()) && user.getRole().equals(userDetails.getRole())){
//				userDetailsBean = getUserDetail(user.getUserId());
//				isValid=true;
//				break;	
//			}
//		}
//		return userDetailsBean;
//	}
//
//	@Override
//	public UserDetailsBean getUserDetail(int userId) throws HBMSException {
//		
//		return userDetailsDao.getUserDetail(userId);
//	}
//
//	@Override
//	public boolean isValidCredentials(UserDetailsBean userDetailsBean)
//			throws HBMSException {
//
//		System.out.println("entering isValidCred");
//		//System.out.println(userDetailsBean);
//		boolean isValid = false;
//		List<UserDetailsBean> usersList = userDetailsDao.usersDetail();
//
//		System.out.println(usersList);
//		for(UserDetailsBean user : usersList){
//			if(user.getUserName().equals(userDetailsBean.getUserName()) && 
//					user.getPassword().equals(userDetailsBean.getPassword()) && user.getRole().equals(userDetailsBean.getRole())){
//				isValid=true;
//				break;	
//			}
//		}
//		System.out.println(isValid);
//		return isValid;
//	}
}
