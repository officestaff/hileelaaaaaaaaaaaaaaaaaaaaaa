package com.cg.employee.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "department")
public class Department {
	@Id
	@Column(name = "dept_id")
	@NotNull(message = "Department code should not be empty")
	@Range(min = 1, max = 3, message = "Department code should be valid code")
	private Integer deptId;

	@Column(name = "dept_name")
	@NotEmpty(message = "Department name should not be empty")
	private String deptName;

	public Integer getDeptCode() {
		return deptId;
	}

	public void setDeptCode(Integer deptCode) {
		this.deptId = deptCode;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

}