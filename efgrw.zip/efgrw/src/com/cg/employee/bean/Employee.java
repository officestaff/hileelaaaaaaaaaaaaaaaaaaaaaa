package com.cg.employee.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "employee")
public class Employee {

	@Id
	@Column(name = "emp_id")
	private Integer employeeId;

	@Column(name = "emp_first_name")
	@NotEmpty(message = "First Name cannot be Empty")
	@Pattern(regexp = "^[A-Z][a-z]{3,30}$", message = "Name should start with upper case followed by lower case letters and minimum 4 characters. ")
	private String fsName;

	@Column(name = "emp_last_name")
	@NotEmpty(message = "Last Name cannot be Empty")
	@Pattern(regexp = "^[A-Z][a-z]{3,30}$", message = "Name should start with upper case followed by lower case letters and minimum 4 characters.")
	private String lsName;

	@Column(name = "emp_date_of_birth")
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date dob;

	@Column(name = "emp_date_of_joining")
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date doj;

	@Column(name = "emp_dept_id")
	private int deptId;

	@Column(name = "emp_grade")
	@NotEmpty(message = "Grade cannot be Empty")
	private String grade;

	@Column(name = "emp_designation")
	@NotEmpty(message = "Designation cannot be Empty")
	@Pattern(regexp = "^[A-Z][a-z]{3,50}$", message = "Designation must have characters with size less than 50.")
	private String designation;

	@Column(name = "emp_basic")
	@NotNull(message = "Salary cannot be empty")
	private Integer basSal;

	@Column(name = "emp_gender")
	@NotEmpty(message = "Please select one of the option")
	private String gender;

	@Column(name = "emp_marital_status")
	@NotEmpty(message = "Please select one of the option")
	private String mStatus;

	@Column(name = "emp_home_address")
	@NotEmpty(message = "Address cannot be Empty")
	private String address;

	@Column(name = "emp_contact_num")
	@NotEmpty(message = "Contact number cannot be Empty")
	@Pattern(regexp = "^[789][0-9]{9}$", message = "Please enter a valid contact number of size 10 starting with 7,8 or 9")
	private String contactNo;

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFsName() {
		return fsName;
	}

	public void setFsName(String fsName) {
		this.fsName = fsName;
	}

	public String getLsName() {
		return lsName;
	}

	public void setLsName(String lsName) {
		this.lsName = lsName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Integer getBasSal() {
		return basSal;
	}

	public void setBasSal(Integer basSal) {
		this.basSal = basSal;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getmStatus() {
		return mStatus;
	}

	public void setmStatus(String mStatus) {
		this.mStatus = mStatus;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", fsName=" + fsName
				+ ", lsName=" + lsName + ", dob=" + dob + ", doj=" + doj
				+ ", deptId=" + deptId + ", grade=" + grade + ", designation="
				+ designation + ", basSal=" + basSal + ", gender=" + gender
				+ ", mStatus=" + mStatus + ", address=" + address
				+ ", contactNo=" + contactNo + "]";
	}

}
