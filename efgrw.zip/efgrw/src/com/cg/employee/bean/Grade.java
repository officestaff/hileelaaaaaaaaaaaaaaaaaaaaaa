package com.cg.employee.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "grade_master")
public class Grade {
	@Id
	@Column(name = "grade_code")
	@NotEmpty(message = "Grade code should not be empty")
	@Size(max = 2)
	private String gradeCode;
	@Column(name = "description")
	@NotEmpty(message = "Grade description should not be empty")
	private String gradeDescription;
	@Column(name = "min_salary")
	@NotNull(message = "Minimum salary should not be empty")
	private int minSal;
	@Column(name = "max_salary")
	@NotNull(message = "Maximum salary should not be empty")
	private int maxSal;

	public String getGradeCode() {
		return gradeCode;
	}

	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}

	public String getGradeDescription() {
		return gradeDescription;
	}

	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}

	public int getMinSal() {
		return minSal;
	}

	public void setMinSal(int minSal) {
		this.minSal = minSal;
	}

	public int getMaxSal() {
		return maxSal;
	}

	public void setMaxSal(int maxSal) {
		this.maxSal = maxSal;
	}

}
