package com.cg.employee.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "user_master")
public class Login {
	@Id
	@NotNull
	@Column(name = "UserId")
	private int userId;
	@Column(name = "UserName")
	@Size(min = 3, message = "User Name must contain at least 3 characters")
	private String userName;

	@Override
	public String toString() {
		return "Login [userId=" + userId + ", userName=" + userName
				+ ", userPassword=" + userPassword + ", userType=" + userType
				+ "]";
	}

	public Login() {
		super();
	}

	@Column(name = "UserPassword")
	@Size(min = 3, message = "Password must contain at least 3 characters")
	private String userPassword;
	@Column(name = "UserType")
	private String userType;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
}