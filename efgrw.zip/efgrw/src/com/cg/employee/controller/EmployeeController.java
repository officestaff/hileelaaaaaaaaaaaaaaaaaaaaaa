package com.cg.employee.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employee.bean.Department;
import com.cg.employee.bean.Employee;
import com.cg.employee.bean.Grade;
import com.cg.employee.bean.Leave;
import com.cg.employee.bean.Login;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.IEmployeeService;

@Controller
public class EmployeeController {

	List<Login> logged;
	Employee employee;

	@Autowired
	private IEmployeeService service;
	
	
	@RequestMapping("/")
	public ModelAndView showLoginPage() throws Exception {
		return new ModelAndView("Home");
	}
	@RequestMapping("/Admin")
	public ModelAndView showAdminPage() throws Exception {
		return new ModelAndView("Admin");
	}
	
	@RequestMapping("/Login")
	public ModelAndView loginPage() throws Exception {
		Login login = new Login();
		return new ModelAndView("Login", "login", login);
	}
	
	@RequestMapping("/checkLogin")
	public ModelAndView login(
			@ModelAttribute(value = "login") @Valid Login login,
			BindingResult result, Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		if (result.hasErrors()) {
			return new ModelAndView("Login");
		} else {
			try {
				if (login.getUserPassword() != "" && login.getUserName() != "") {
					logged = service.getAllUser(login.getUserName());
					if (!logged.isEmpty()) {
						if (login.getUserPassword().equals(
								logged.get(0).getUserPassword())) {
							if (logged.get(0).getUserType().equals("admin")) {
								mv = new ModelAndView("Admin");
							} else if (logged.get(0).getUserType()
									.equals("user")) {
								mv = new ModelAndView("User");
							}
						} else {
							mv.setViewName("Login");
							model.addAttribute("msg", "Password Mismatch");
						}
					} else {
						mv.setViewName("Login");
						model.addAttribute("msg", "No user found");
					}
				} else {
					mv = new ModelAndView("Login");
					model.addAttribute("msg", "Enter all required fields");
				}
			} catch (EmployeeException exception) {
				exception.printStackTrace();
			}
		}
		return mv;
	}
	
	@RequestMapping(value = "addEmployee", method = RequestMethod.GET)
	public String addEmployee(@ModelAttribute(value = "employee") Employee emp,
			Map<String, Object> model) throws EmployeeException {
		List<Department> department = new ArrayList<>();
		department = service.showAllDepartment();
		model.put("department", department);
		List<Grade> grade = new ArrayList<>();
		grade = service.showAllGrade();
		model.put("grade", grade);
		List<Grade> grade1 = new ArrayList<>();
		grade1 = service.showAllDepartments();
		model.put("grade1", grade1);
		
		return "Addemployee";
	}

	@RequestMapping(value = "success", method = RequestMethod.POST)
	public String addEmployeeDataDatabase(
			@Valid @ModelAttribute("employee") Employee emp,
			BindingResult result, Map<String, Integer> mapData,
			Map<String, Object> model, Model models,
			@RequestParam("dob") String dob1, @RequestParam("doj") String doj1) throws EmployeeException {
		if (result.hasErrors()) {
			List<Department> department = new ArrayList<>();
			department = service.showAllDepartment();
			model.put("department", department);
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			try {
				formatter.parse(dob1);
				formatter.parse(doj1);
			} catch (ParseException e) {

				models.addAttribute("dob1",
						"Date of birth should be in format:dd-MM-yyyy");
				models.addAttribute("doj1",
						"Date of joining should be in format: dd-MM-yyyy");

			}
			List<Grade> grade = new ArrayList<>();
			grade = service.showAllGrade();
			model.put("grade", grade);
			
			List<Grade> grade1 = new ArrayList<>();
			grade1 = service.showAllDepartments();
			model.put("grade1", grade1);
			return "Addemployee";

		} else {
			ModelAndView view = new ModelAndView();

			Date dob = emp.getDob();
			Date doj = emp.getDoj();

			@SuppressWarnings("deprecation")
			int a = dob.getYear();
			@SuppressWarnings("deprecation")
			int b = doj.getYear();

			int age = b - a;
			if (service.ageValidation(age)) {
				if (emp.getGrade().equals("M1") && emp.getDesignation().equalsIgnoreCase("Analyst")) {
					if (emp.getBasSal() > 0 && emp.getBasSal() <= 15000) {
						int empId = service.addEmployee(emp);
						mapData.put("empId", empId);
						return "insertsuccess";
					} else {
						model.put("message",
								"Enter salary in the range 0-15000");
					}
				} else if (emp.getGrade().equals("M2") && emp.getDesignation().equalsIgnoreCase("Tester")) {
					if (emp.getBasSal() > 15000 && emp.getBasSal() <= 25000) {
						int empId = service.addEmployee(emp);
						mapData.put("empId", empId);
						return "insertsuccess";
					} else {
						model.put("message",
								"Enter salary in the range 15000-25000");
					}
				} else if (emp.getGrade().equals("M3") && emp.getDesignation().equalsIgnoreCase("Designer")) {
					if (emp.getBasSal() > 25000 && emp.getBasSal() <= 40000) {
						int empId = service.addEmployee(emp);
						mapData.put("empId", empId);
						return "insertsuccess";
					} else {
						model.put("message",
								"Enter salary in the range 25000-40000");
					}
				} else if (emp.getGrade().equals("M4") && emp.getDesignation().equalsIgnoreCase("Coder")) {
					if (emp.getBasSal() > 40000 && emp.getBasSal() <= 75000) {
						int empId = service.addEmployee(emp);
						mapData.put("empId", empId);
						return "insertsuccess";
					} else {
						model.put("message",
								"Enter salary in the range 40000-75000");
					}
				} else if (emp.getGrade().equals("M5") && emp.getDesignation().equalsIgnoreCase("Manager")) {
					if (emp.getBasSal() > 75000 && emp.getBasSal() <=100000) {
						int empId = service.addEmployee(emp);
						mapData.put("empId", empId);
						return "insertsuccess";
					} else {
						model.put("message",
								"Enter salary in the range 75000-100000");
					}
				} else if (emp.getGrade().equals("M6") && emp.getDesignation().equalsIgnoreCase("HR")) {
					if (emp.getBasSal() > 100000 && emp.getBasSal() <= 125000) {
						int empId = service.addEmployee(emp);
						mapData.put("empId", empId);
						return "insertsuccess";
					} else {
						model.put("message",
								"Enter salary in the range 100000-125000");
					}
				} else if (emp.getGrade().equals("M7") && emp.getDesignation().equalsIgnoreCase("Director")) {
					if (emp.getBasSal() > 125000) {
						int empId = service.addEmployee(emp);
						mapData.put("empId", empId);
						return "insertsuccess";
					} else {
						model.put("message", "Enter salary greater than 125000");
					}
				} else {
					
					model.put("message", "Enter valid grade");
					List<Department> department = new ArrayList<>();
					department = service.showAllDepartment();
					model.put("department", department);
					List<Grade> grade = new ArrayList<>();
					grade = service.showAllGrade();
					model.put("grade", grade);
					List<Grade> grade1 = new ArrayList<>();
					grade1 = service.showAllDepartments();
					model.put("grade1", grade1);
					
				}

			} else {
				List<Department> department = new ArrayList<>();
				department = service.showAllDepartment();
				model.put("department", department);

				List<Grade> grade = new ArrayList<>();
				grade = service.showAllGrade();
				model.put("grade", grade);
				
				List<Grade> grade1 = new ArrayList<>();
				grade1 = service.showAllDepartments();
				model.put("grade1", grade1);

				String st = "Age should be between 18 and 58 years";
				model.put("message", st);

			}
			return "Addemployee";
		}
	}
	
	@RequestMapping(value = "displayEmployee", method = RequestMethod.GET)
	public ModelAndView showEmployeeData() {
		List<Employee> employees = null;
		try {
			employees = service.showAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("Displayemployee", "empshow", employees);

	}
	
	@RequestMapping("modifyEmployee")
	public String home() {
		return "modifySearch";
	}

	@RequestMapping(value = "search1", method = RequestMethod.GET)
	public ModelAndView modifySearch(@RequestParam("empId") int empId,
			Map<String, Object> model) throws EmployeeException {
		List<Department> department = new ArrayList<>();
		department = service.showAllDepartment();
		model.put("department", department);

		List<Grade> grade = new ArrayList<>();
		grade = service.showAllGrade();
		model.put("grade", grade);

		Employee emp = new Employee();

		try {
			emp = service.view(empId);
		} catch (Exception exception) {
			String st = "Please Enter valid employee id";
			model.put("message", st);
			return new ModelAndView("search");
		}
		return new ModelAndView("Modifyemployee", "emp", emp);

	}

	@RequestMapping(value = "modemp1", method = RequestMethod.POST)
	public String update(@ModelAttribute("emp") Employee emp,
			Map<String, Integer> mapData, BindingResult result,
			Map<String, Object> model) throws EmployeeException {

		if (result.hasErrors()) {
			List<Department> department = new ArrayList<>();
			department = service.showAllDepartment();
			model.put("department", department);

			List<Grade> grade = new ArrayList<>();
			grade = service.showAllGrade();
			model.put("grade", grade);
			

			List<Grade> grade1 = new ArrayList<>();
			grade1 = service.showAllDepartments();
			model.put("grade1", grade1);

			return "Addemployee";
		}

		else {
			int empId = service.modify(emp);
			try {
				mapData.put("id", empId);
			} catch (Exception exception) {
				exception.printStackTrace();
			}
			return "successupdate";
		}
	}
	
	@RequestMapping("/applyLeave")
	public ModelAndView showApplyPage() throws Exception {
		return new ModelAndView("applyLeave");
	}
	@RequestMapping("/ApproveLeave")
	public ModelAndView showApprovePage() throws Exception {
		return new ModelAndView("ApproveLeave");
	}
	
	
	@RequestMapping(value = "Viewleaves", method = RequestMethod.GET)
	public ModelAndView showViewLeavesPage() {
		List<Leave> leaveshow = null;
		try {
			leaveshow = service.showAllLeaves();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("Viewleaves", "leaveshow", leaveshow);
	}
	
	@RequestMapping(value = "/searchEmployee")
	public String displaySearchPage(Model model) {
		return "searchEmp";
	}
	
	@RequestMapping(value = "searchEmployeeFname", method = RequestMethod.GET)
	public ModelAndView searchingEmployees(@RequestParam("fsName") String fname,
			Map<String, Object> model) {
		
		
		List<Employee> employeeshow = new ArrayList<>();
		try {
			employeeshow = service.showSearchedEmployees(fname);
			model.get(fname);
		} catch (EmployeeException e1) {
			e1.printStackTrace();
		}
		model.put("employeeshow", employeeshow);

		return new ModelAndView("searchEmp", "employeeshow", employeeshow);
	}
		
		
	@RequestMapping(value = "/showContactUs")
	public String displayContactUsPage(Model model) {
		return "ContactUs";
	}

	@RequestMapping(value = "/showAboutUs")
	public String displayAboutUsPage(Model model) {
		return "AboutUs";
	}

}
	

