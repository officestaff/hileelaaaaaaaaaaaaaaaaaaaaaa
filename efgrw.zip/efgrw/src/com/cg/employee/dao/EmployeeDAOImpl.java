package com.cg.employee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.employee.bean.Department;
import com.cg.employee.bean.Employee;
import com.cg.employee.bean.Grade;
import com.cg.employee.bean.Leave;
import com.cg.employee.bean.Login;
import com.cg.employee.exception.EmployeeException;


@Repository
@Transactional
public class EmployeeDAOImpl implements IEmployeeDAO {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Login> getAllUser(String userName) throws EmployeeException {
		String qstr = "SELECT m FROM Login m WHERE m.userName LIKE :pnumber";
		TypedQuery<Login> query = entityManager.createQuery(qstr, Login.class);
		query.setParameter("pnumber", "%" + userName + "%");
		List<Login> loginList = query.getResultList();
		return loginList;
	}

	@Override
	public int addEmployee(Employee emp) {
		entityManager.persist(emp);
		entityManager.flush();
		return emp.getEmployeeId();
	}

	@Override
	public List<Department> showAllDepartment() {
		Query queryOne = entityManager
				.createQuery("select deptId from Department");
		List<Department> dataList = queryOne.getResultList();
		return dataList;
	}

	@Override
	public List<Grade> showAllGrade() {
		Query queryOne = entityManager
				.createQuery("select gradeCode from Grade");
		List<Grade> dataList = queryOne.getResultList();
		return dataList;
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		TypedQuery<Employee> query = entityManager.createQuery(
				"SELECT t1 FROM Employee t1", Employee.class);
		return query.getResultList();
	}

	@Override
	public int modify(Employee emp) {
		Query queryOne = entityManager
				.createQuery("UPDATE Employee SET fsName=:fname,lsName=:lname,deptId=:dept,grade=:grd,designation=:des,basSal=:bsal,mStatus=:mst,address=:addr,contactNo=:cont WHERE employeeId=:empid");
		queryOne.setParameter("fname", emp.getFsName());
		queryOne.setParameter("lname", emp.getLsName());
		queryOne.setParameter("dept", emp.getDeptId());
		queryOne.setParameter("grd", emp.getGrade());
		queryOne.setParameter("des", emp.getDesignation());
		queryOne.setParameter("bsal", emp.getBasSal());
		queryOne.setParameter("mst", emp.getmStatus());
		queryOne.setParameter("addr", emp.getAddress());
		queryOne.setParameter("cont", emp.getContactNo());
		queryOne.setParameter("empid", emp.getEmployeeId());
		queryOne.executeUpdate();
		return emp.getEmployeeId();
	}

	@Override
	public Employee view(int employeeId) {
		Query queryThree = entityManager
				.createQuery("from Employee where employeeId=:employeeId");
		queryThree.setParameter("employeeId", employeeId);
		Employee emp = (Employee) queryThree.getResultList().get(0);
		return emp;
	}

	@Override
	public List<Leave> showAllLeaves() throws EmployeeException {
		TypedQuery<Leave> query = entityManager.createQuery(
				"SELECT s1 FROM Leave s1", Leave.class);
		return query.getResultList();
	}

	@Override
	public List<Employee> showSearchedEmployees(String fsName) throws EmployeeException {
		Query query = entityManager.createQuery("from Employee where fsName=:fsName");
		query.setParameter("fsName", fsName);
		
		return  query.getResultList();
		
		
		
	}

	@Override
	public List<Grade> showAllDepartments() throws EmployeeException {
		Query queryOne = entityManager
				.createQuery("select gradeDescription from Grade");
		List<Grade> dataList = queryOne.getResultList();
		return dataList;
	}

	

}
