package com.cg.employee.dao;

import java.util.List;

import com.cg.employee.bean.Department;
import com.cg.employee.bean.Employee;
import com.cg.employee.bean.Grade;
import com.cg.employee.bean.Leave;
import com.cg.employee.bean.Login;
import com.cg.employee.exception.EmployeeException;


public interface IEmployeeDAO {
	List<Login> getAllUser(String userName) throws EmployeeException;

	public int addEmployee(Employee emp) throws EmployeeException;

	public List<Department> showAllDepartment() throws EmployeeException;

	public List<Grade> showAllGrade() throws EmployeeException;

	public List<Employee> showAll() throws EmployeeException;

	public List<Grade> showAllDepartments() throws EmployeeException;

	public int modify(Employee emp) throws EmployeeException;
	
	public List<Leave> showAllLeaves() throws EmployeeException;

	public Employee view(int employeeId) throws EmployeeException;

	List<Employee> showSearchedEmployees(String fsName) throws EmployeeException;

}