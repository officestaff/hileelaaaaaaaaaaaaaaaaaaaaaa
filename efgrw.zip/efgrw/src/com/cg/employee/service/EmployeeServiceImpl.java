package com.cg.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.employee.bean.Department;
import com.cg.employee.bean.Employee;
import com.cg.employee.bean.Grade;
import com.cg.employee.bean.Leave;
import com.cg.employee.bean.Login;
import com.cg.employee.dao.IEmployeeDAO;
import com.cg.employee.exception.EmployeeException;

@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {
	@Autowired
	private IEmployeeDAO dao;

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		return dao.addEmployee(emp);
	}

	@Override
	public List<Department> showAllDepartment() throws EmployeeException {
		return dao.showAllDepartment();
	}

	@Override
	public List<Grade> showAllGrade() throws EmployeeException {
		return dao.showAllGrade();
	}

	@Override
	public boolean ageValidation(Integer age) {
		if (age >= 18 && age <= 60)
			return true;
		else
			return false;
	}

	@Override
	public List<Login> getAllUser(String userName) throws EmployeeException {
		return dao.getAllUser(userName);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		return dao.showAll();
	}

	@Override
	public int modify(Employee emp) throws EmployeeException {
		return dao.modify(emp);
	}

	@Override
	public Employee view(int employeeId) throws EmployeeException {
		return dao.view(employeeId);
	}

	@Override
	public List<Leave> showAllLeaves() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.showAllLeaves();
	}

	@Override
	public List<Employee> showSearchedEmployees(String fsName) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.showSearchedEmployees(fsName);
	}

	@Override
	public List<Grade> showAllDepartments() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.showAllDepartments();
	}





}