package com.cg.employee.service;

import java.util.List;

import com.cg.employee.bean.Department;
import com.cg.employee.bean.Employee;
import com.cg.employee.bean.Grade;
import com.cg.employee.bean.Leave;
import com.cg.employee.bean.Login;
import com.cg.employee.exception.EmployeeException;


public interface IEmployeeService {
	List<Login> getAllUser(String string) throws EmployeeException;

	public int addEmployee(Employee emp) throws EmployeeException;

	public List<Department> showAllDepartment() throws EmployeeException;

	public List<Grade> showAllGrade() throws EmployeeException;
	
	public List<Grade> showAllDepartments() throws EmployeeException;

	boolean ageValidation(Integer age) throws EmployeeException;

	public List<Employee> showAll() throws EmployeeException;
	public List<Leave> showAllLeaves() throws EmployeeException;


	public int modify(Employee emp) throws EmployeeException;

	public Employee view(int employeeId) throws EmployeeException;


	public List<Employee> showSearchedEmployees(String fsName) throws EmployeeException;


}